import setuptools

setuptools.setup(
    name="Sanniboina-Jagadeesh",
    version="0.0.1",
    packages=setuptools.find_packages(),
)
